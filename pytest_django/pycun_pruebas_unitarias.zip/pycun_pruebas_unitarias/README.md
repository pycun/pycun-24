## PyTest

1. Estructura para ejecutar pruebas mediante PyTest

```shell
repo/
   |--app.py
   |--settings.py
   |--models.py
   |--tests/
          |--test_app.py
```

2. Comando para ejecutar Pruebas

```shell
python -m pytest pycun_pruebas_unitarias/tests/ -v
```
